Sample Parallax Scrolling
=========================
Đây là ví dụ đơn giản về kỹ thuật "parallax scrolling"
