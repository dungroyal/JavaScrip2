<?php
$username = $_POST['username'];
$password = $_POST['password'];
if ($username == 'dungdq' && $password == 'ps08542') {
    echo 0;
}else{
    echo 1;
}
?>